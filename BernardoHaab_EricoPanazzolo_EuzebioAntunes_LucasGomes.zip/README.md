## Execução do programa

`java -jar .\T1_SisOp.jar`

O programa ira pedir as seguintes informações:

- arquivo do processo:
  - Nome do arquivo texto com as instruções. O arquivo deve estar na mesma pasta do programa. Ex: `./prog1.txt`
- Arraival time:
  - Tempo a partir do qual este processo deve estar disponível para ser escalonado. Ex: `1`
- Computation time:
  - Tempo necessário para a execução completa da tarefa. Ex: `4`
- Deadline:
  - Tempo limite para o programa ser executado. Ex: `15`
